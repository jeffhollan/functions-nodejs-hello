If you wanted to deploy this today NOT using porter, you would do the following:

## Using the Azure CLI

```bash
az group create -n $resourceGroup -l westus2
az storage account create -g $resourceGroup -n $uniqueStorageName --sku Standard_LRS
```